ref<-"Not_Dilated"
expressfile<- read.delim("~/Downloads/GSE30657/DilatationExpression.txt")
DEGfile <- read.delim("~/Downloads/GSE30657/Dilated_vs_noDilated.txt")
targets <- readTargets("~/Downloads/GSE30657/targets.txt")
colnames(DEGfile)

#Identificar a coluna comum entre o arquivo da expressão e o DEG
expressfile<-expressfile[match(DEGfile$EnsemblId,expressfile$EnsemblID),]

#Criar os vetores com o nome das amostras de cada grupo
Cntlposition<-logical()
for (i in 1:nrow(targets)){
  if((targets$Condition[i])==ref){
    Cntlposition<-c(Cntlposition,TRUE)
  }
  else
    Cntlposition<-c(Cntlposition,FALSE)
}

controlSamples<-targets[Cntlposition,1]
ProbeSamples<-targets[!Cntlposition,1]

#Calcular a média das expressões de cada grupo, só a fim de ver qual é maior
expressfile$CntlAVG<-rowMeans(expressfile[,colnames(expressfile)%in%controlSamples])
expressfile$ProbesAVG<-rowMeans(expressfile[,colnames(expressfile)%in%ProbeSamples])

reverseFCSignal<-(expressfile$CntlAVG>expressfile$ProbesAVG)

for (i in 1:length(reverseFCSignal)){
  if(reverseFCSignal[i]){
    DEGfile$SignalFC[i]<-(DEGfile$logFC[i]*-1)
  }
  else{
    DEGfile$SignalFC[i]<-DEGfile$logFC[i]
  }
}

