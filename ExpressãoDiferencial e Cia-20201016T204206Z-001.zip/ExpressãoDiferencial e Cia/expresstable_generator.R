#Para um Elist y, salvao arquivo de expressão


#Recuperar a tabela de expressão
exprs<-as.data.frame(y$E)
colnames(exprs)<-factor(SDRF[,1])
exprs$Entrez<-y$genes$TargetID
write.table(exprs,"NormalizedExpression.csv",sep = "\t",row.names = FALSE)
